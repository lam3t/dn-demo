# CẨM NANG HƯỚNG DẪN TRIỂN KHAI HỆ THỐNG TN EDU LÊN WINDOWS SERVER

Tài liệu hướng dẫn chi tiết từng bước từ cài đặt môi trường, cấu hình Cơ sở dữ liệu PostgreSQL, khởi chạy Backend API, triển khai Frontend và thiết lập Web Server (Nginx / IIS) trên môi trường **Windows Server (2016 / 2019 / 2022 / Windows 10/11 Pro)**.

---

## MỤC LỤC
1. [Cấu trúc Gói Triển Khai](#1-cấu-trúc-gói-triển-khai)
2. [Tùy chọn A: Triển khai 1-Chạm bằng DOCKER (Khuyên dùng)](#tùy-chọn-a-triển-khai-1-chạm-bằng-docker-khuyên-dùng)
3. [Tùy chọn B: Triển khai Trực tiếp trên Windows (Node.js + PostgreSQL)](#tùy-chọn-b-triển-khai-trực-tiếp-trên-windows-nodejs--postgresql)
   - [Bước 1: Cài đặt & Khởi tạo CSDL PostgreSQL](#bước-1-cài-đặt--khởi-tạo-csdl-postgresql)
   - [Bước 2: Cấu hình & Khởi chạy Backend API](#bước-2-cấu-hình--khởi-chạy-backend-api)
   - [Bước 3: Triển khai Frontend & Web Server (Nginx hoặc IIS)](#bước-3-triển-khai-frontend--web-server-nginx-hoặc-iis)
4. [Mở Port trên Windows Defender Firewall & Router Internet](#bước-4-mở-port-trên-windows-defender-firewall)
5. [Thiết lập Tự Động Sao Lưu Dữ Liệu (Backup)](#bước-5-thiết-lập-tự-động-sao-lưu-dữ-liệu-backup)
6. [Thông tin Đăng nhập & Vận hành Ban đầu](#thông-tin-đăng-nhập--vận-hành-ban-đầu)

---

## 1. Cấu trúc Gói Triển Khai

Sau khi giải nén gói `deploy-package.zip`, bạn sẽ có cấu trúc thư mục như sau:

```
deploy-package/
├── frontend/
│   └── dist/                     # Toàn bộ file tĩnh Production của Frontend Angular
├── backend/
│   ├── dist/                     # Mã nguồn JavaScript Node.js đã build
│   ├── prisma/
│   │   └── schema.prisma         # Schema dữ liệu Prisma
│   ├── package.json              # File định nghĩa thư viện runtime
│   ├── .env.example              # Mẫu cấu hình môi trường
│   └── ecosystem.config.js       # File cấu hình PM2 quản lý tiến trình
├── database/
│   ├── 01_schema.sql             # SQL tạo toàn bộ Bảng, Index, Khóa ngoại
│   └── 02_baseline_seed.sql      # SQL nạp 60 Quyền, 2 Gói dịch vụ & TK System Admin
├── scripts/
│   ├── 1-setup-database.bat      # Script khởi tạo Database 1 chạm
│   ├── 2-start-backend.bat       # Script khởi chạy Backend nhanh
│   └── 3-backup-database.bat     # Script sao lưu CSDL tự động
└── WINDOWS_SERVER_DEPLOYMENT_GUIDE.md
```

---

## Tùy chọn A: Triển khai 1-Chạm bằng DOCKER (Khuyên dùng)

Triển khai bằng Docker là giải pháp nhanh nhất, tự động 100%, cô lập môi trường hoàn hảo, không lo xung đột phiên bản Node.js hay PostgreSQL trên máy chủ.

### 1. Chuẩn bị môi trường Docker
- Cài đặt **Docker Desktop for Windows**: [https://www.docker.com/products/docker-desktop/](https://www.docker.com/products/docker-desktop/) (hoặc Docker Engine nếu dùng Windows Server bản Core).
- Đảm bảo Docker đang chạy (biểu tượng cá voi màu xanh góc taskbar).

### 2. Khởi chạy toàn bộ hệ thống (1-Chạm)
1. Giải nén gói `deploy-package`.
2. Chạy file **`scripts\start-docker.bat`** (hoặc mở CMD tại thư mục `deploy-package` và gõ `docker compose up -d --build`).
3. Hệ thống sẽ tự động build và khởi chạy 3 container:
   - **`tn_edu_postgres`**: Cơ sở dữ liệu PostgreSQL 16, **tự động nạp sẵn toàn bộ Schema và Seed System Admin** từ file `tn_edu_complete_init.sql`.
   - **`tn_edu_backend`**: Backend API Node.js/Prisma lắng nghe tại port 5000.
   - **`tn_edu_frontend`**: Nginx Web Server lắng nghe tại port 80, tự động phục vụ Angular SPA và Reverse Proxy `/api/` vào backend container.

### 3. Các lệnh quản lý Docker thường dùng:
```bash
# Xem trạng thái các container đang chạy
docker compose ps

# Xem log thời gian thực của backend
docker compose logs -f backend

# Dừng toàn bộ hệ thống
docker compose down (hoặc chạy file scripts\stop-docker.bat)

# Khởi động lại hệ thống
docker compose restart
```

---

## Tùy chọn B: Triển khai Trực tiếp trên Windows (Node.js + PostgreSQL)

### Yêu cầu Môi trường & Phần mềm cần cài:
Tải và cài đặt các phần mềm sau trên Windows Server:
1. **Node.js LTS (v20.x hoặc v22.x)**: Tải file `.msi` tại [https://nodejs.org/](https://nodejs.org/).
2. **PostgreSQL (v15.x hoặc v16.x)**: Tải tại [EnterpriseDB](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads).
3. **PM2**: `npm install -g pm2 pm2-windows-service`.
     ```powershell
     npm install -g pm2 pm2-windows-service
     ```
4. **Web Server**: Chọn **Nginx for Windows** (khuyên dùng) hoặc **IIS**.

---

## Bước 1: Cài đặt & Khởi tạo CSDL PostgreSQL

### Cách A (Khuyên dùng - Sử dụng Script tự động):
1. Vào thư mục `scripts/`.
2. Click đúp chuột vào file **`1-setup-database.bat`**.
3. Nhập mật khẩu tài khoản `postgres` khi được hỏi. Script sẽ tự động tìm `psql`, tạo CSDL `tn_edu` và nạp toàn bộ dữ liệu.

### Cách B (Thủ công 1 bước bằng pgAdmin 4):
1. Mở công cụ **pgAdmin 4**.
2. Chuột phải vào `Databases` -> Chọn `Create` -> `Database...` -> Đặt tên là `tn_edu` -> Bấm `Save`.
3. Chuột phải vào database `tn_edu` vừa tạo -> Chọn **Query Tool**.
4. Mở file **`database/tn_edu_complete_init.sql`** (đã gộp sẵn cả Schema và Seed chuẩn) -> Nhấn **Execute (F5)**.
5. Kiểm tra thông báo: `Query returned successfully` là xong!

---

## Bước 2: Cấu hình & Khởi chạy Backend API

### 1. Cấu hình biến môi trường
1. Vào thư mục `backend/`.
2. Sao chép file `.env.example` thành file **`.env`**.
3. Mở file `.env` bằng Notepad và chỉnh sửa chuỗi kết nối Database phù hợp với mật khẩu của bạn:
   ```env
   PORT=5000
   NODE_ENV=production
   
   # Thay "YourSecurePassword123" bằng mật khẩu PostgreSQL thực tế của bạn
   DATABASE_URL="postgresql://postgres:YourSecurePassword123@localhost:5432/tn_edu?schema=public&connection_limit=20"
   DIRECT_URL="postgresql://postgres:YourSecurePassword123@localhost:5432/tn_edu?schema=public"
   
   JWT_SECRET="tn_edu_super_prod_secret_2026_jwt_token_secure"
   JWT_REFRESH_SECRET="tn_edu_super_prod_refresh_secret_2026_secure"
   JWT_ACCESS_EXPIRES_IN="7d"
   JWT_REFRESH_EXPIRES_IN="30d"
   
   CORS_ORIGIN="http://localhost,http://127.0.0.1,http://localhost:80"
   ```

### 2. Cài đặt Dependencies & Sinh Prisma Client
Mở cửa sổ Command Prompt (CMD) tại thư mục `backend/` và chạy:
```cmd
npm install --omit=dev
npx prisma generate
```

### 3. Khởi chạy Backend

#### Tùy chọn 1: Chạy thử nhanh bằng Batch Script
- Chạy file `scripts/2-start-backend.bat`. Backend sẽ lắng nghe tại `http://localhost:5000`.

#### Tùy chọn 2: Chạy Service nền vĩnh viễn bằng PM2 (Khuyên dùng cho Production)
Mở PowerShell (Administrator) tại thư mục `backend/`:
```powershell
# 1. Khởi chạy ứng dụng qua PM2
pm2 start ecosystem.config.js

# 2. Lưu trạng thái PM2
pm2 save

# 3. Cài đặt tự khởi động cùng Windows Server khi reboot máy
pm2-service-install -n "TN_EDU_Backend"
```
*Lưu ý:* Để xem log của backend, chạy `pm2 logs tn-edu-backend`. Để xem trạng thái, chạy `pm2 status`.

---

## Bước 3: Triển khai Frontend & Web Server (Nginx hoặc IIS)

---

### Cách 1: Triển khai bằng Nginx for Windows (Khuyên dùng)

1. Tải Nginx for Windows tại: [https://nginx.org/en/download.html](https://nginx.org/en/download.html) (ví dụ bản `nginx/Windows-1.24.x`).
2. Giải nén vào ổ đĩa, ví dụ: `C:\nginx`.
3. Sao chép toàn bộ nội dung trong thư mục `deploy-package/frontend/dist/` vào thư mục `C:\nginx\html\tn-edu\`.
4. Mở file `C:\nginx\conf\nginx.conf`, thay thế khối `server { ... }` bằng cấu hình chuẩn sau:

```nginx
server {
    listen       80;
    server_name  localhost qlgd.yourdomain.edu.vn;

    # Gzip nén dữ liệu cho tốc độ tối đa
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript image/svg+xml;

    # 1. Định tuyến Frontend Angular (SPA HTML5 Routing)
    location / {
        root   C:/nginx/html/tn-edu;
        index  index.html;
        try_files $uri $uri/ /index.html;
    }

    # 2. Reverse Proxy chuyển toàn bộ request /api sang Backend Node.js
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        client_max_body_size 50M;
    }

    # 3. Thư mục tải lên minh chứng / file đính kèm
    location /uploads/ {
        proxy_pass http://127.0.0.1:5000/uploads/;
        proxy_set_header Host $host;
    }
}
```

5. Khởi động Nginx:
   Mở Command Prompt tại `C:\nginx` và chạy:
   ```cmd
   start nginx
   ```
   *(Để nạp lại cấu hình: `nginx -s reload`, để dừng: `nginx -s stop`)*.

---

### Cách 2: Triển khai bằng Microsoft IIS (Gắn Domain & Expose ra Internet)

#### Bước 3.1: Cài đặt IIS và 2 Module cốt lõi bắt buộc
1. Mở **Server Manager** -> **Add Roles and Features** -> Chọn **Web Server (IIS)**:
   - Trong mục *Role Services*, tích chọn: `Common HTTP Features` (Default Document, Static Content, HTTP Redirection), `Performance` (Static/Dynamic Content Compression), `Security` (Request Filtering).
2. Tải và cài đặt **2 Module bắt buộc của Microsoft**:
   - **URL Rewrite Module 2.1**: [Tải tại Microsoft IIS URL Rewrite](https://www.iis.net/downloads/microsoft/url-rewrite)
   - **Application Request Routing (ARR 3.0)**: [Tải tại Microsoft IIS ARR](https://www.iis.net/downloads/microsoft/application-request-routing)
   *(Cài đặt xong khởi động lại IIS hoặc gõ lệnh `iisreset` trong CMD)*.

#### Bước 3.2: Bật tính năng Proxy trong ARR (BƯỚC BẮT BUỘC - NẾU BỎ QUA SẼ BỊ LỖI 500)
1. Mở **Internet Information Services (IIS) Manager** (`inetmgr.exe`).
2. Nhấp chuột trái vào **Tên máy chủ (Server Name)** ở cột ngoài cùng bên trái (cấp Root).
3. Ở bảng điều khiển trung tâm, nhấp đúp chuột vào biểu tượng **Application Request Routing Cache**.
4. Ở cột **Actions** bên phải ngoài cùng, bấm vào dòng **Server Proxy Settings...**.
5. Đánh dấu tích vào ô vuông **`Enable proxy`**.
6. (Tùy chọn) Bỏ tích ở ô *`Reverse rewrite host in response headers`*.
7. Bấm **Apply** ở góc trên bên phải để lưu lại.

#### Bước 3.3: Tạo Website mới và Gắn Domain trên IIS
1. Đặt thư mục ứng dụng tại ổ đĩa máy chủ (ví dụ: `C:\TN_EDU\`).
   - Sao chép toàn bộ thư mục `frontend\dist` vào `C:\TN_EDU\frontend\dist`.
2. Mở **IIS Manager** -> Mở rộng cây thư mục -> Chuột phải vào mục **Sites** -> Chọn **Add Website...**:
   - **Site name**: `TN_EDU` (hoặc tên miền của bạn).
   - **Application pool**: `DefaultAppPool` (hoặc `No Managed Code`).
   - **Physical path**: Trỏ tới thư mục `C:\TN_EDU\frontend\dist` (thư mục chứa `index.html` và file `web.config`).
   - **Binding**:
     - Type: `http`
     - IP address: `All Unassigned`
     - Port: `80`
     - Host name: Nhập tên miền của bạn (ví dụ: `qlgd.school.edu.vn` hoặc `edu.tenmien.com`).
   - Nhấn **OK**.
3. **Phân quyền thư mục (Tránh lỗi 401/500 Access Denied)**:
   - Chuột phải vào thư mục `C:\TN_EDU\frontend\dist` trên Windows Explorer -> Chọn **Properties** -> Tab **Security** -> Nhấn **Edit...** -> Nhấn **Add...** -> Nhập `IIS_IUSRS` -> Nhấn **Check Names** -> **OK** -> Cấp quyền `Read & execute` -> Nhấn **OK**.

#### Bước 3.4: Tệp cấu hình `web.config` sẵn có
File `web.config` đã được đóng gói sẵn trong `frontend/dist/web.config` với đầy đủ các tính năng:
- Cho phép upload minh chứng, đính kèm lên tới **50MB** (`maxAllowedContentLength="52428800"`).
- Khai báo MIME types cho `.woff`, `.woff2`, `.json`, `.svg`, `.webmanifest`.
- Tự động Reverse Proxy toàn bộ `/api/*` và `/uploads/*` vào Backend Node.js chạy tại `http://127.0.0.1:5000`.
- SPA HTML5 PushState routing cho ứng dụng Angular.

#### Bước 3.5: Cài Chứng chỉ SSL / HTTPS Miễn phí tự động bằng `win-acme` (Let's Encrypt for IIS)
1. Tải công cụ **win-acme** (chuẩn Let's Encrypt cho Windows IIS): [https://www.win-acme.com/](https://www.win-acme.com/) (Tải bản `win-acme.vX.X.X.x64.pluggable.zip`).
2. Giải nén vào `C:\win-acme\`.
3. Mở **Command Prompt (Administrator)** và gõ:
   ```cmd
   cd C:\win-acme
   wacs.exe
   ```
4. Làm theo các bước trên màn hình tương tác:
   - Chọn `N`: **Create certificate (default settings)**.
   - Chọn số thứ tự của Website **TN_EDU** tương ứng.
   - Chọn `A`: **All bindings**.
   - Nhập địa chỉ Email của bạn (để nhận thông báo từ Let's Encrypt).
   - Nhập `y` để đồng ý điều khoản dịch vụ.
5. `win-acme` sẽ tự động:
   - Tạo chứng chỉ SSL hợp lệ (Let's Encrypt) cho Domain của bạn.
   - Tự cấu hình Binding HTTPS **Port 443** vào IIS.
   - Tự tạo lịch trình trong **Windows Task Scheduler** để tự động gia hạn chứng chỉ trước khi hết hạn mỗi 60 ngày!

---

## Bước 4: Mở Port trên Windows Defender Firewall

Mở **PowerShell (Administrator)** và chạy các lệnh sau để cho phép máy trạm khác trong mạng LAN/Internet truy cập vào hệ thống:

```powershell
# Mở Port 80 (HTTP)
New-NetFirewallRule -DisplayName "TN_EDU_HTTP_80" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow

# Mở Port 443 (HTTPS - nếu cài SSL)
New-NetFirewallRule -DisplayName "TN_EDU_HTTPS_443" -Direction Inbound -LocalPort 443 -Protocol TCP -Action Allow
```

---

## Bước 5: Thiết lập Tự Động Sao Lưu Dữ Liệu (Backup)

1. Mở công cụ **Task Scheduler** trên Windows Server (`taskschd.msc`).
2. Chọn **Create Basic Task...**
   - Name: `TN_EDU_Daily_Database_Backup`.
   - Trigger: Chọn **Daily** (Chạy hàng ngày lúc 23:00 đêm).
   - Action: Chọn **Start a program**.
   - Program/script: Trỏ đến file `scripts\3-backup-database.bat`.
   - Start in: Nhập đường dẫn thư mục `scripts` (ví dụ `C:\TN_EDU\scripts`).
3. Nhấn **Finish**. Hàng ngày hệ thống sẽ tự động xuất file `.sql` sao lưu lưu vào thư mục `backups/`.

---

## Thông tin Đăng nhập & Vận hành Ban đầu

Truy cập hệ thống qua trình duyệt: `http://localhost` (hoặc `http://<IP_MÁY_CHỦ>`).

### Tài khoản Quản trị Nền tảng SaaS (System Admin):
- **Tài khoản**: `0913016667` *(hoặc `chunh@tringhiatech.vn`)*
- **Mật khẩu**: `123456`

### Quy trình tạo Trường học (Tenant) thật đầu tiên:
1. Đăng nhập bằng tài khoản **System Admin** ở trên.
2. Hệ thống sẽ tự động chuyển tới giao diện Quản trị Nền tảng SaaS (`/system-admin`).
3. Nhấn nút **"+ Thêm trường học mới"**.
4. Nhập đầy đủ thông tin:
   - Tên trường (ví dụ: *Trường THPT Chuyên Hùng Vương*).
   - Mã trường (ví dụ: *THPT_CHV*).
   - Gói dịch vụ: *Gói Cơ bản (Standard)* hoặc *Gói Nâng cao (Enterprise)*.
   - Họ tên và Số điện thoại / Email của **Hiệu trưởng / Quản trị viên trường**.
   - Mật khẩu khởi tạo.
5. Nhấn **"Khởi tạo Tenant"**.
6. Đăng xuất và sử dụng tài khoản Admin trường vừa tạo để đăng nhập vào không gian điều hành trường học thật!
