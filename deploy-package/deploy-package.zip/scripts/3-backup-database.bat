@echo off
chcp 65001 > nul
title TN EDU - Sao lưu CSDL PostgreSQL tự động
echo ======================================================================
echo    TN EDU - TỰ ĐỘNG SAO LƯU CƠ SỞ DỮ LIỆU POSTGRESQL (BACKUP)
echo ======================================================================
echo.

set PG_HOST=localhost
set PG_PORT=5432
set PG_USER=postgres
set PG_DB=tn_edu

rem Tạo thư mục backups nếu chưa có
if not exist "%~dp0..\backups" mkdir "%~dp0..\backups"

rem Lấy ngày giờ định dạng YYYY-MM-DD_HH-MM-SS
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set TIMESTAMP=%datetime:~0,4%-%datetime:~4,2%-%datetime:~6,2%_%datetime:~8,2%-%datetime:~10,2%-%datetime:~12,2%
set BACKUP_FILE=%~dp0..\backups\tn_edu_backup_%TIMESTAMP%.sql

echo Đang tiến hành sao lưu database "%PG_DB%" vào:
echo %BACKUP_FILE%
echo.

pg_dump -h %PG_HOST% -p %PG_PORT% -U %PG_USER% -d %PG_DB% -F p -b -v -f "%BACKUP_FILE%"

if %errorlevel% equ 0 (
    echo.
    echo ======================================================================
    echo ✓ SAO LƯU DỮ LIỆU THÀNH CÔNG!
    echo File sao lưu: %BACKUP_FILE%
    echo ======================================================================
) else (
    echo.
    echo [LỖI] Sao lưu dữ liệu thất bại!
)

echo.
timeout /t 5
