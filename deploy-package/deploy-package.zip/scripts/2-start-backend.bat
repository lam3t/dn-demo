@echo off
chcp 65001 > nul
title TN EDU - Khởi chạy Backend Service trên Windows Server
echo ======================================================================
echo    TN EDU - KHỞI CHẠY BACKEND SERVICE (PORT 5000)
echo ======================================================================
echo.

cd /d "%~dp0..\backend"

if not exist ".env" (
    echo [CẢNH BÁO] Chưa tìm thấy file .env, đang sao chép từ .env.example...
    copy ".env.example" ".env"
    echo Vui lòng chỉnh sửa mật khẩu Database trong file "backend\.env" nếu cần!
    notepad ".env"
)

if not exist "node_modules" (
    echo [1/2] Đang cài đặt thư viện Production dependencies...
    call npm install --omit=dev
    echo [2/2] Đang sinh mã Prisma Client...
    call npx prisma generate
)

echo.
echo ======================================================================
echo    Đang khởi động Backend API trên http://localhost:5000 ...
echo    (Nhấn Ctrl + C để dừng dịch vụ)
echo ======================================================================
echo.
node dist/index.js

pause
