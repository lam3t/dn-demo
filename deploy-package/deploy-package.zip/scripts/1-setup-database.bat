@echo off
chcp 65001 > nul
title TN EDU - Khởi tạo CSDL PostgreSQL trên Windows Server
echo ======================================================================
echo    TN EDU - CÔNG CỤ KHỞI TẠO CƠ SỞ DỮ LIỆU POSTGRESQL TỰ ĐỘNG
echo ======================================================================
echo.

set PG_HOST=localhost
set PG_PORT=5432
set PG_USER=postgres
set PG_DB=tn_edu

echo [1/3] Vui lòng nhập thông tin kết nối PostgreSQL (nhấn Enter để dùng mặc định):
set /p USER_HOST="Host [%PG_HOST%]: "
if not "%USER_HOST%"=="" set PG_HOST=%USER_HOST%

set /p USER_PORT="Port [%PG_PORT%]: "
if not "%USER_PORT%"=="" set PG_PORT=%USER_PORT%

set /p USER_NAME="User [%PG_USER%]: "
if not "%USER_NAME%"=="" set PG_USER=%USER_NAME%

set /p USER_DB="Database Name [%PG_DB%]: "
if not "%USER_DB%"=="" set PG_DB=%USER_DB%

set /p PGPASSWORD="Mật khẩu PostgreSQL của user %PG_USER%: "
echo.

echo [2/3] Kiểm tra và tạo cơ sở dữ liệu "%PG_DB%"...
psql -h %PG_HOST% -p %PG_PORT% -U %PG_USER% -d postgres -c "SELECT 1 FROM pg_database WHERE datname = '%PG_DB%';" | find "1" > nul
if %errorlevel% neq 0 (
    echo Database "%PG_DB%" chưa tồn tại, đang tiến hành tạo mới...
    psql -h %PG_HOST% -p %PG_PORT% -U %PG_USER% -d postgres -c "CREATE DATABASE %PG_DB% ENCODING 'UTF8';"
    if %errorlevel% neq 0 (
        echo [LỖI] Không thể tạo database. Vui lòng kiểm tra lại mật khẩu hoặc dịch vụ PostgreSQL!
        pause
        exit /b %errorlevel%
    )
    echo ✓ Tạo database "%PG_DB%" thành công!
) else (
    echo ✓ Database "%PG_DB%" đã sẵn sàng.
)

echo.
echo [3/3] Đang nạp Schema (01_schema.sql) và Dữ liệu nền tảng (02_baseline_seed.sql)...
psql -h %PG_HOST% -p %PG_PORT% -U %PG_USER% -d %PG_DB% -f "..\database\01_schema.sql"
if %errorlevel% neq 0 (
    echo [LỖI] Nạp 01_schema.sql thất bại!
    pause
    exit /b %errorlevel%
)
echo ✓ Đã tạo toàn bộ Bảng, Index và Ràng buộc toàn vẹn thành công.

psql -h %PG_HOST% -p %PG_PORT% -U %PG_USER% -d %PG_DB% -f "..\database\02_baseline_seed.sql"
if %errorlevel% neq 0 (
    echo [LỖI] Nạp 02_baseline_seed.sql thất bại!
    pause
    exit /b %errorlevel%
)
echo ✓ Đã khởi tạo 60 Quyền phân hệ, 2 Gói dịch vụ và Tài khoản System Admin thành công.

echo.
echo ======================================================================
echo    KHỞI TẠO CƠ SỞ DỮ LIỆU THÀNH CÔNG RỰC RỠ!
echo    Tài khoản Quản trị Nền tảng (System Admin):
echo    - Tài khoản: 0913016667 (hoặc chunh@tringhiatech.vn)
echo    - Mật khẩu:  123456
echo ======================================================================
echo.
pause
